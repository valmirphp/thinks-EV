<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('financial_settlements', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('financial_entry_id');
            $table->decimal('amount',20,6);
            $table->char('currency_code',3);
            $table->foreignId('money_conversion_id')->nullable();
            $table->timestamp('settled_at');
            $table->string('reference',100)->nullable();
            $table->timestamps();

            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','financial_entry_id'])->references(['company_id','id'])->on('financial_entries')->restrictOnDelete();
            $table->foreign(['company_id','money_conversion_id'])->references(['company_id','id'])->on('money_conversions')->restrictOnDelete();
            $table->foreign('currency_code')->references('code')->on('currencies');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('financial_settlements');
    }
};
