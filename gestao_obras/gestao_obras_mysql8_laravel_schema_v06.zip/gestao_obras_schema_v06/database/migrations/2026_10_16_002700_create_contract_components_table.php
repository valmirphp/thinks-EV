<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('contract_components', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('contract_id');
            $table->string('type',30);
            $table->string('description');
            $table->decimal('amount',20,6)->nullable();
            $table->string('fee_type',20)->nullable();
            $table->decimal('fee_value',20,6)->nullable();
            $table->json('calculation_rules')->nullable();
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','contract_id'])->references(['company_id','id'])->on('contracts')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contract_components');
    }
};
