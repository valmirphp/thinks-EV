<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('offline_operations', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('device_id')->constrained('mobile_devices')->restrictOnDelete();
            $table->uuid('operation_uuid');
            $table->string('resource_type',80);
            $table->string('action',40);
            $table->char('payload_hash',64);
            $table->unsignedBigInteger('client_version')->nullable();
            $table->string('status',30)->default('received');
            $table->timestamp('received_at');
            $table->timestamp('processed_at')->nullable();
            $table->timestamps();
            $table->unique(['device_id','operation_uuid']);
            $table->index(['company_id','status','received_at']);
            $table->unique(['company_id','id']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('offline_operations');
    }
};
