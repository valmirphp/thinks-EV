<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('task_dependencies', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('company_id');
            $table->foreignId('project_id');
            $table->foreignId('task_id');
            $table->foreignId('depends_on_task_id');
            $table->timestamps();
            $table->unique(['task_id','depends_on_task_id']);
            $table->foreign(['company_id','project_id'])->references(['company_id','id'])->on('projects')->restrictOnDelete();
            $table->foreign(['company_id','task_id'])->references(['company_id','id'])->on('project_tasks')->cascadeOnDelete();
            $table->foreign(['company_id','depends_on_task_id'])->references(['company_id','id'])->on('project_tasks')->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('task_dependencies');
    }
};
