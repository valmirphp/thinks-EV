<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('membership_roles', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('company_id');
            $table->foreignId('membership_id');
            $table->foreignId('role_id');
            $table->timestamps();
            $table->unique(['membership_id','role_id']);
            $table->foreign(['company_id','membership_id'])->references(['company_id','id'])->on('company_memberships')->cascadeOnDelete();
            $table->foreign(['company_id','role_id'])->references(['company_id','id'])->on('roles')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('membership_roles');
    }
};
