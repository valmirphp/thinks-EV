<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('budget_items', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('budget_version_id');
            $table->string('description');
            $table->string('unit',24);
            $table->decimal('quantity',18,6);
            $table->decimal('unit_price',20,6);
            $table->decimal('estimated_cost',20,6)->default(0);
            $table->timestamps();

            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','budget_version_id'])->references(['company_id','id'])->on('budget_versions')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('budget_items');
    }
};
