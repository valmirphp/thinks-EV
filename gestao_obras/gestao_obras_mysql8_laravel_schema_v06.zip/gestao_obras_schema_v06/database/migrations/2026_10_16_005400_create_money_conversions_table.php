<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('money_conversions', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->decimal('source_amount',20,6);
            $table->char('source_currency_code',3);
            $table->decimal('target_amount',20,6);
            $table->char('target_currency_code',3);
            $table->decimal('applied_rate',24,12);
            $table->timestamp('effective_at');
            $table->string('source',100);
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign('source_currency_code')->references('code')->on('currencies');
            $table->foreign('target_currency_code')->references('code')->on('currencies');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('money_conversions');
    }
};
