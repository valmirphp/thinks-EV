<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('stock_movements', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('warehouse_id');
            $table->foreignId('material_id');
            $table->foreignId('movement_request_id')->nullable();
            $table->string('movement_type',30);
            $table->decimal('quantity_delta',18,6);
            $table->decimal('balance_after',18,6);
            $table->string('reference_type',60)->nullable();
            $table->unsignedBigInteger('reference_id')->nullable();
            $table->foreignId('created_by')->constrained('users')->restrictOnDelete();
            $table->text('reason')->nullable();
            $table->timestamps();
            $table->index(['company_id','warehouse_id','material_id','created_at']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','warehouse_id'])->references(['company_id','id'])->on('warehouses')->restrictOnDelete();
            $table->foreign(['company_id','material_id'])->references(['company_id','id'])->on('materials')->restrictOnDelete();
            $table->foreign(['company_id','movement_request_id'])->references(['company_id','id'])->on('stock_movement_requests')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stock_movements');
    }
};
