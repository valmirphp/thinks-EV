<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('financial_entries', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('project_id')->nullable();
            $table->foreignId('contract_id')->nullable();
            $table->foreignId('category_id')->nullable();
            $table->string('entry_type',20);
            $table->decimal('amount',20,6);
            $table->char('currency_code',3);
            $table->date('due_on')->nullable();
            $table->string('status',30)->default('open');
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->index(['company_id','status','due_on']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','project_id'])->references(['company_id','id'])->on('projects')->restrictOnDelete();
            $table->foreign(['company_id','contract_id'])->references(['company_id','id'])->on('contracts')->restrictOnDelete();
            $table->foreign(['company_id','category_id'])->references(['company_id','id'])->on('financial_categories')->restrictOnDelete();
            $table->foreign('currency_code')->references('code')->on('currencies');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('financial_entries');
    }
};
