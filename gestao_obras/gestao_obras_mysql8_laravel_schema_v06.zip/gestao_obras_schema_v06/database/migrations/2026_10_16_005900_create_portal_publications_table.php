<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('portal_publications', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('project_id');
            $table->string('resource_type',80);
            $table->unsignedBigInteger('resource_id');
            $table->unsignedInteger('resource_version');
            $table->string('visibility',30)->default('client');
            $table->timestamp('published_at')->nullable();
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->index(['company_id','project_id','resource_type','resource_id']);
            $table->foreign(['company_id','project_id'])->references(['company_id','id'])->on('projects')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('portal_publications');
    }
};
