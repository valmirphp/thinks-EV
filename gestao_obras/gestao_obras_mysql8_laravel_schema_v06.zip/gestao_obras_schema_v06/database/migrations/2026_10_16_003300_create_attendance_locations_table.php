<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('attendance_locations', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('attendance_id');
            $table->string('event_type',20);
            $table->decimal('latitude',10,7);
            $table->decimal('longitude',10,7);
            $table->decimal('accuracy_m',10,2)->nullable();
            $table->timestamp('captured_at');
            $table->timestamp('received_at')->nullable();
            $table->timestamps();

            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','attendance_id'])->references(['company_id','id'])->on('attendance_records')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('attendance_locations');
    }
};
