<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('project_members', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('company_id');
            $table->foreignId('project_id');
            $table->foreignId('membership_id');
            $table->string('responsibility',100)->nullable();
            $table->timestamps();
            $table->unique(['project_id','membership_id']);
            $table->foreign(['company_id','project_id'])->references(['company_id','id'])->on('projects')->restrictOnDelete();
            $table->foreign(['company_id','membership_id'])->references(['company_id','id'])->on('company_memberships')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('project_members');
    }
};
