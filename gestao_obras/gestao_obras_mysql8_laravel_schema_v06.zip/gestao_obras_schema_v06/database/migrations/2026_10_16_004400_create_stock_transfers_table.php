<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('stock_transfers', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('source_warehouse_id');
            $table->foreignId('target_warehouse_id');
            $table->string('status',30)->default('requested');
            $table->foreignId('requested_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('received_at')->nullable();
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','source_warehouse_id'])->references(['company_id','id'])->on('warehouses')->restrictOnDelete();
            $table->foreign(['company_id','target_warehouse_id'])->references(['company_id','id'])->on('warehouses')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stock_transfers');
    }
};
