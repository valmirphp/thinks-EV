<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('change_order_items', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('change_order_id');
            $table->string('description');
            $table->decimal('amount_delta',20,6)->default(0);
            $table->timestamps();

            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','change_order_id'])->references(['company_id','id'])->on('change_orders')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('change_order_items');
    }
};
