<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('daily_reports', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('project_id');
            $table->date('report_date');
            $table->foreignId('author_id')->constrained('users')->restrictOnDelete();
            $table->string('status',30)->default('draft');
            $table->text('notes')->nullable();
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->index(['company_id','project_id','report_date']);
            $table->foreign(['company_id','project_id'])->references(['company_id','id'])->on('projects')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('daily_reports');
    }
};
