<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('measurement_items', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('measurement_id');
            $table->foreignId('contract_component_id')->nullable();
            $table->string('description');
            $table->decimal('quantity',18,6)->default(0);
            $table->decimal('cumulative_quantity',18,6)->default(0);
            $table->decimal('amount',20,6)->default(0);
            $table->timestamps();

            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','measurement_id'])->references(['company_id','id'])->on('measurements')->restrictOnDelete();
            $table->foreign(['company_id','contract_component_id'])->references(['company_id','id'])->on('contract_components')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('measurement_items');
    }
};
