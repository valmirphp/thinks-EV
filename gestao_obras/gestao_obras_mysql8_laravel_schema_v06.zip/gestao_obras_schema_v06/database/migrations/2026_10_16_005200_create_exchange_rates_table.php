<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('exchange_rates', function (Blueprint $table): void {
            $table->id();
            $table->char('base_currency_code',3);
            $table->char('quote_currency_code',3);
            $table->decimal('rate',24,12);
            $table->string('source',100);
            $table->timestamp('effective_at');
            $table->string('status',24)->default('valid');
            $table->timestamps();
            $table->index(['base_currency_code','quote_currency_code','effective_at']);
            $table->foreign('base_currency_code')->references('code')->on('currencies');
            $table->foreign('quote_currency_code')->references('code')->on('currencies');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('exchange_rates');
    }
};
