<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('approval_decisions', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('approval_request_id');
            $table->foreignId('actor_user_id')->constrained('users')->restrictOnDelete();
            $table->string('decision',30);
            $table->text('comment')->nullable();
            $table->timestamp('decided_at');
            $table->char('evidence_hash',64);
            $table->ipAddress('ip_address')->nullable();
            $table->timestamps();

            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','approval_request_id'])->references(['company_id','id'])->on('approval_requests')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('approval_decisions');
    }
};
