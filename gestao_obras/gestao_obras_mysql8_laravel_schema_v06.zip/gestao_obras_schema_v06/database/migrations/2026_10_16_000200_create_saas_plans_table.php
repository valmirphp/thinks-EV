<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('saas_plans', function (Blueprint $table): void {
            $table->id();
            $table->string('code',60)->unique();
            $table->string('name');
            $table->json('limits')->nullable();
            $table->boolean('active')->default(true);
            $table->timestamps();


        });
    }

    public function down(): void
    {
        Schema::dropIfExists('saas_plans');
    }
};
