<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('contracts', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('project_id');
            $table->foreignId('client_id');
            $table->string('contract_number',60);
            $table->string('model',30);
            $table->char('currency_code',3);
            $table->decimal('original_amount',20,6)->default(0);
            $table->decimal('current_amount',20,6)->default(0);
            $table->string('status',30)->default('draft');
            $table->timestamp('accepted_at')->nullable();
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->unique(['company_id','contract_number']);
            $table->foreign(['company_id','project_id'])->references(['company_id','id'])->on('projects')->restrictOnDelete();
            $table->foreign(['company_id','client_id'])->references(['company_id','id'])->on('clients')->restrictOnDelete();
            $table->foreign('currency_code')->references('code')->on('currencies');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contracts');
    }
};
