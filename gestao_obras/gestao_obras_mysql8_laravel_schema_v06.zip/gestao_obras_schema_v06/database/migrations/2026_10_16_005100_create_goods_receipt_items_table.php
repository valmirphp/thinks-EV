<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('goods_receipt_items', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('goods_receipt_id');
            $table->foreignId('purchase_order_item_id');
            $table->decimal('received_quantity',18,6);
            $table->decimal('rejected_quantity',18,6)->default(0);
            $table->timestamps();

            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','goods_receipt_id'])->references(['company_id','id'])->on('goods_receipts')->restrictOnDelete();
            $table->foreign(['company_id','purchase_order_item_id'])->references(['company_id','id'])->on('purchase_order_items')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('goods_receipt_items');
    }
};
