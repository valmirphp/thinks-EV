<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('client_portal_memberships', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('project_id');
            $table->foreignId('client_id');
            $table->foreignId('user_id')->constrained()->restrictOnDelete();
            $table->string('status',24)->default('active');
            $table->boolean('can_approve')->default(false);
            $table->timestamps();
            $table->unique(['project_id','user_id']);
            $table->foreign(['company_id','project_id'])->references(['company_id','id'])->on('projects')->restrictOnDelete();
            $table->foreign(['company_id','client_id'])->references(['company_id','id'])->on('clients')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('client_portal_memberships');
    }
};
