<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('saas_subscriptions', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('saas_account_id')->constrained()->restrictOnDelete();
            $table->foreignId('saas_plan_id')->constrained()->restrictOnDelete();
            $table->string('status',24);
            $table->timestamp('starts_at')->nullable();
            $table->timestamp('ends_at')->nullable();
            $table->timestamps();
            $table->index(['saas_account_id','status']);

        });
    }

    public function down(): void
    {
        Schema::dropIfExists('saas_subscriptions');
    }
};
