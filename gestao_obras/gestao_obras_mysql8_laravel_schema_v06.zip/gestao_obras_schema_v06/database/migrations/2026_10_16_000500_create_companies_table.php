<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('companies', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('saas_account_id')->constrained()->restrictOnDelete();
            $table->string('legal_name');
            $table->string('trade_name')->nullable();
            $table->string('tax_id',60)->nullable();
            $table->char('country_code',2);
            $table->char('base_currency_code',3);
            $table->string('timezone',64)->default('America/Sao_Paulo');
            $table->string('status',24)->default('active');
            $table->timestamps();
            $table->unique(['id','saas_account_id']);
            $table->index(['saas_account_id','status']);
            $table->foreign('base_currency_code')->references('code')->on('currencies')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('companies');
    }
};
