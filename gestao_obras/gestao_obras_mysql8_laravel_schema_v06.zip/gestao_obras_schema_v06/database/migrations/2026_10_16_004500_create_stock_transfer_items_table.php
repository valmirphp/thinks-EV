<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('stock_transfer_items', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('stock_transfer_id');
            $table->foreignId('material_id');
            $table->decimal('requested_quantity',18,6);
            $table->decimal('received_quantity',18,6)->default(0);
            $table->timestamps();

            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','stock_transfer_id'])->references(['company_id','id'])->on('stock_transfers')->restrictOnDelete();
            $table->foreign(['company_id','material_id'])->references(['company_id','id'])->on('materials')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stock_transfer_items');
    }
};
