<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('sync_conflicts', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('offline_operation_id');
            $table->string('reason',100);
            $table->unsignedBigInteger('server_version')->nullable();
            $table->unsignedBigInteger('client_version')->nullable();
            $table->string('resolution_status',30)->default('pending');
            $table->timestamps();

            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','offline_operation_id'])->references(['company_id','id'])->on('offline_operations')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('sync_conflicts');
    }
};
