<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('stock_authorizations', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('movement_request_id');
            $table->foreignId('approver_id')->constrained('users')->restrictOnDelete();
            $table->decimal('balance_before',18,6);
            $table->decimal('balance_after',18,6);
            $table->text('justification');
            $table->timestamp('approved_at');
            $table->timestamps();

            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','movement_request_id'])->references(['company_id','id'])->on('stock_movement_requests')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('stock_authorizations');
    }
};
