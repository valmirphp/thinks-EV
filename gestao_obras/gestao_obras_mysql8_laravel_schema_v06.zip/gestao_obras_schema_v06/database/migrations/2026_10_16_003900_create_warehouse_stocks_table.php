<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('warehouse_stocks', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('company_id');
            $table->foreignId('warehouse_id');
            $table->foreignId('material_id');
            $table->decimal('quantity_on_hand',18,6)->default(0);
            $table->decimal('quantity_reserved',18,6)->default(0);
            $table->unsignedBigInteger('version')->default(1);
            $table->timestamps();
            $table->unique(['company_id','warehouse_id','material_id']);
            $table->unique(['company_id','id']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','warehouse_id'])->references(['company_id','id'])->on('warehouses')->restrictOnDelete();
            $table->foreign(['company_id','material_id'])->references(['company_id','id'])->on('materials')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('warehouse_stocks');
    }
};
