<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('change_orders', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('contract_id');
            $table->unsignedInteger('version_no')->default(1);
            $table->text('reason');
            $table->decimal('amount_delta',20,6)->default(0);
            $table->integer('days_delta')->default(0);
            $table->string('status',30)->default('draft');
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','contract_id'])->references(['company_id','id'])->on('contracts')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('change_orders');
    }
};
