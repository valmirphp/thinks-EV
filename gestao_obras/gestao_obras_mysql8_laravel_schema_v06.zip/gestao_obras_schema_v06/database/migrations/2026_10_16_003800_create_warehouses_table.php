<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('warehouses', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('project_id')->nullable();
            $table->string('code',60);
            $table->string('name');
            $table->string('type',24);
            $table->boolean('active')->default(true);
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->unique(['company_id','code']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','project_id'])->references(['company_id','id'])->on('projects')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('warehouses');
    }
};
