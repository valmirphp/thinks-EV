<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('project_tasks', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('project_id');
            $table->foreignId('stage_id')->nullable();
            $table->foreignId('assignee_membership_id')->nullable();
            $table->string('title');
            $table->text('description')->nullable();
            $table->string('status',30)->default('todo');
            $table->date('due_on')->nullable();
            $table->unsignedBigInteger('version')->default(1);
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->index(['company_id','project_id','status']);
            $table->foreign(['company_id','project_id'])->references(['company_id','id'])->on('projects')->restrictOnDelete();
            $table->foreign(['company_id','stage_id'])->references(['company_id','id'])->on('project_stages')->restrictOnDelete();
            $table->foreign(['company_id','assignee_membership_id'])->references(['company_id','id'])->on('company_memberships')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('project_tasks');
    }
};
