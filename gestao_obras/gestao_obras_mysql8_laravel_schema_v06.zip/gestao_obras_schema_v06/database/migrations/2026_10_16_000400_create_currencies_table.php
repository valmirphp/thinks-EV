<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('currencies', function (Blueprint $table): void {
            $table->id();
            $table->char('code',3)->unique();
            $table->string('name',80);
            $table->unsignedTinyInteger('minor_units')->default(2);
            $table->boolean('active')->default(true);
            $table->timestamps();


        });
    }

    public function down(): void
    {
        Schema::dropIfExists('currencies');
    }
};
