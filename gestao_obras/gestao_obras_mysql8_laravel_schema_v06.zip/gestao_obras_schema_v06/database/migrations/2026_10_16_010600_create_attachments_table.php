<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('attachments', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('project_id')->nullable();
            $table->string('owner_type',80);
            $table->unsignedBigInteger('owner_id');
            $table->string('storage_key',600);
            $table->char('checksum',64)->nullable();
            $table->string('visibility',30)->default('internal');
            $table->unsignedBigInteger('size_bytes')->default(0);
            $table->timestamps();
            $table->index(['company_id','owner_type','owner_id']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','project_id'])->references(['company_id','id'])->on('projects')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('attachments');
    }
};
