<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('purchase_order_items', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('purchase_order_id');
            $table->foreignId('material_id');
            $table->decimal('quantity',18,6);
            $table->decimal('unit_price',20,6);
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','purchase_order_id'])->references(['company_id','id'])->on('purchase_orders')->restrictOnDelete();
            $table->foreign(['company_id','material_id'])->references(['company_id','id'])->on('materials')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('purchase_order_items');
    }
};
