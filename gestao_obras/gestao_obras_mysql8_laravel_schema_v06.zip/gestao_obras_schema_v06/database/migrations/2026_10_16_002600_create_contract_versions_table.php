<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('contract_versions', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('contract_id');
            $table->unsignedInteger('version_no');
            $table->json('snapshot');
            $table->char('snapshot_hash',64);
            $table->foreignId('created_by')->constrained('users')->restrictOnDelete();
            $table->timestamp('approved_at')->nullable();
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->unique(['contract_id','version_no']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','contract_id'])->references(['company_id','id'])->on('contracts')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('contract_versions');
    }
};
