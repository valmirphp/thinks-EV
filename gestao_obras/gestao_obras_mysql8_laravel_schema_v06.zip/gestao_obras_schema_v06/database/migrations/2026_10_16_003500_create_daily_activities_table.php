<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('daily_activities', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('project_id');
            $table->foreignId('daily_report_id')->nullable();
            $table->foreignId('task_id')->nullable();
            $table->foreignId('employee_id')->nullable();
            $table->text('description');
            $table->decimal('hours',8,2)->nullable();
            $table->decimal('progress_percent',7,4)->nullable();
            $table->timestamps();

            $table->foreign(['company_id','project_id'])->references(['company_id','id'])->on('projects')->restrictOnDelete();
            $table->foreign(['company_id','daily_report_id'])->references(['company_id','id'])->on('daily_reports')->restrictOnDelete();
            $table->foreign(['company_id','task_id'])->references(['company_id','id'])->on('project_tasks')->restrictOnDelete();
            $table->foreign(['company_id','employee_id'])->references(['company_id','id'])->on('employees')->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('daily_activities');
    }
};
