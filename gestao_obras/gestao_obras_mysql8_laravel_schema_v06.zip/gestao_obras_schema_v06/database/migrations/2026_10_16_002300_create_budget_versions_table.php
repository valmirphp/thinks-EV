<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration {
    public function up(): void
    {
        Schema::create('budget_versions', function (Blueprint $table): void {
            $table->id();
            $table->uuid('public_id')->unique();
            $table->foreignId('company_id');
            $table->foreignId('budget_id');
            $table->unsignedInteger('version_no');
            $table->char('currency_code',3);
            $table->timestamp('approved_at')->nullable();
            $table->json('snapshot')->nullable();
            $table->timestamps();
            $table->unique(['company_id','id']);
            $table->unique(['budget_id','version_no']);
            $table->foreign('company_id')->references('id')->on('companies')->restrictOnDelete();
            $table->foreign(['company_id','budget_id'])->references(['company_id','id'])->on('budgets')->restrictOnDelete();
            $table->foreign('currency_code')->references('code')->on('currencies');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('budget_versions');
    }
};
