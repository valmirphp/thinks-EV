# Esquema físico MySQL 8+ / Laravel — Gestão de Obras v0.6

**68 migrations geradas**. Decisão: **MySQL 8+**, não PostgreSQL. Os arquivos são uma **base física inicial** para revisão e testes de integração, não um sistema de produção pronto.

## Instalação
1. Configure Laravel com `DB_CONNECTION=mysql`, MySQL 8+, `utf8mb4`, engine InnoDB.
2. Copie `database/migrations/*.php` para `database/migrations/` do projeto Laravel.
3. Rode `php artisan migrate` em um banco **vazio**. Não misture com migrations padrão de `users` já existentes sem consolidar as tabelas.
4. Rode testes de integridade, tenant isolation e concorrência antes de dados reais.

## Organização
Os arquivos têm prefixo temporal crescente para respeitar dependências. O módulo de cada tabela está documentado em `docs/manifest.json`. Laravel executa migrations por timestamp; evite mover para subpastas sem configurar `--path` e ordem.

## Estratégia de isolamento
- Cada tabela operacional contém `company_id`.
- FKs compostas `(company_id, foreign_id)` apontam para `(company_id, id)` nos relacionamentos críticos, impedindo ligação cruzada entre empresas.
- `CompanyMembership` controla autorização por empresa, não somente usuário global.
- Aplicar Policies/Gates, middleware de tenant, scopes explícitos, testes de acesso cruzado e validação de IDs públicos. MySQL **não tem RLS nativo**.
- Referências polimórficas (`resource_type`/`resource_id`, `owner_type`/`owner_id`) não podem ser protegidas por FK SQL convencional: validar no serviço de domínio.
- `company_id` precisa ser verificado contra o tenant da sessão em cada criação/atualização; FKs não substituem autorização.

## Depósitos e estoque
- `warehouses.type` = `central` ou `project`; `project_id` obrigatório para depósito de obra, nulo para central (validar via serviço ou CHECK).
- `warehouse_stocks` mantém saldos materializados por depósito e material.
- `stock_movements` é o ledger; confirmar movimento e atualizar saldo **na mesma transação** com `SELECT ... FOR UPDATE`.
- Transferência: solicitação, saída origem, trânsito, recebimento destino. Não creditar destino antes de recebimento confirmado.
- Saldo negativo exige solicitação + autorização segundo alçada e revalidação do saldo no momento da baixa.
- A movimentação de estoque por obra é obtida a partir dos depósitos ligados à obra.

## Cuidados antes de produção
- Adicionar CHECKs e regras de domínio: tipo de contrato, moeda diferente em pares de câmbio, `clock_out >= clock_in`, `quantity > 0`, origem ≠ destino, taxas > 0, campos condicionais de depósito e regras de alçada.
- Implementar máquina de estados e imutabilidade de contratos aprovados, decisões, movimentos e logs na camada de domínio, com restrições adicionais onde possível.
- Rever índices com EXPLAIN e carga real; configurar backup, criptografia e política de retenção de GPS.
- Projetar jobs de câmbio, notificações e armazenamento de fotos; não estão implementados nestas migrations.
- Os relacionamentos `resource_type/resource_id` do portal são polimórficos e exigem verificação de company/project e versão.
- O modelo de presença não deve ser confundido com folha de pagamento ou ponto eletrônico legal.
- Alguns relacionamentos pertencem à mesma empresa, mas não necessariamente à mesma obra; serviços devem validar também `project_id` (ex.: medição e contrato).
- Não executar `migrate:fresh` em ambientes com dados reais.

## Testes mínimos
1. Tentar vincular projeto da empresa A a cliente da empresa B → FK deve falhar.
2. Tentar vincular item de compra da empresa A a material da B → FK deve falhar.
3. Criar usuários com permissões diferentes em empresas do mesmo grupo e verificar autorização.
4. Executar saídas concorrentes com saldo insuficiente e validar alçadas.
5. Reenviar operação offline com mesmo `(device_id, operation_uuid)` e validar unicidade.
6. Criar aceite do cliente de uma versão, revisar o documento e exigir novo aceite.
7. Simular taxas de câmbio ausentes; relatório não pode somar moedas sem taxa.

## Decisões ainda pendentes
- Provedor de câmbio, frequência e política de fallback.
- Base elegível para taxa percentual em contratos por administração.
- Níveis e valores das alçadas de estoque negativo.
- Necessidade de múltiplos depósitos por obra e controle por lote/série.
- Plataforma móvel (PWA/híbrido/nativo) após PoC iOS/Android.
- Regras de aceite e eventual assinatura eletrônica por país.
- Política de privacidade, precisão e retenção do GPS.
- Matriz de permissões e perfis de usuários.
